#pragma once

const unsigned INITIAL_CAPACITY = 8;
const unsigned INITIAL_COUNT = 0;
const unsigned BORROW_MAX_COUNT = 5;
