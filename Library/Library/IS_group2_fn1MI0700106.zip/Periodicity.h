enum class Periodicity
{
	Weekly,
	Monthly,
	Yearly
};